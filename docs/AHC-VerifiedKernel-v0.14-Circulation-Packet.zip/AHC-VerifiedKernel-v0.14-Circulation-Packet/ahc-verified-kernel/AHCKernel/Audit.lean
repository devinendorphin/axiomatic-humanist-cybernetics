/-
  Axiom audit. Building this module prints the axiom dependencies of every
  named theorem in the kernel. Expected result: every theorem depends on at
  most `propext` and `Quot.sound` (standard Lean kernel axioms); none
  depends on `Classical.choice`; several depend on no axioms at all.

  A theorem listed here that acquires an unexpected axiom — or a `sorry`,
  which surfaces as the `sorryAx` axiom — will be visible in the build log.
-/
import AHCKernel.TieredProtocol
import AHCKernel.CrisisCap
import AHCKernel.SensorsAndKernel
import AHCKernel.PLOL
import AHCKernel.ExceedanceBridge
import AHCKernel.SeamLedger

open AHC

-- Module 1: Tiered Evidence-Action Protocol (§5.4, §9.2–9.3)
#print axioms tier_monotone
#print axioms severity_le_evidence
#print axioms sub_causal_reversible
#print axioms irreversible_iff_causal
#print axioms broadcast_universal
#print axioms pio_ceiling
#print axioms pio_reversible
#print axioms pio_resolves
#print axioms no_chatter
-- Temporal hysteresis (S1-S3, adopted v0.2; finding AHC-P1-002)
#print axioms oscillation_travel
#print axioms flip_anchored
#print axioms travel_reanchor
#print axioms flips_travel_anchored
#print axioms chatter_requires_travel
-- Episode machine: PIO with two clocks (E1-E11, adopted v0.4; ruling D-R1A + D-R4)
#print axioms epPendingHours_exhausted
#print axioms epIssuances_exhausted
#print axioms epPendingHours_pending
#print axioms epIssuances_pending_zero
#print axioms episode_no_relitigation
#print axioms episode_single_issuance
#print axioms expiry_routes_by_risk
#print axioms reonset_refloors
#print axioms floor_persists
#print axioms hold_resolution_iff
#print axioms novel_restart_from_spent
#print axioms novel_restart_from_hold
#print axioms exceedance_cannot_restart
#print axioms hold_floor_reversible
#print axioms hold_floor_severity
#print axioms hold_grants_no_more_than_pio
-- Typed dispositions and the clocked hold (E12-E15, adopted v0.10;
-- findings R2-03, R2-06)
#print axioms close_cannot_launder
#print axioms hold_clock_bounded
#print axioms overdue_absorbing
#print axioms overdue_resolution_iff
#print axioms unreviewed_hold_expires
-- Certified reversibility envelopes (W1-W9, adopted v0.4; rulings D-R2A + D-R3)
#print axioms cert_tier_monotone
#print axioms cert_severity_le_evidence
#print axioms cert_sub_causal_reversible
#print axioms cert_irreversible_iff_causal
#print axioms uncertified_routing_needs_causal
#print axioms uncertified_severance_needs_causal
#print axioms certified_route_at_t1
#print axioms certified_severance_at_t2
#print axioms cert_refinement_conservative
#print axioms no_certificate_no_presumption
#print axioms zero_envelope_constructible
-- Certified PIO and hold authorization (W10-W18, adopted v0.9; finding R2-01)
#print axioms pio_cert_ceiling
#print axioms pio_cert_reversible
#print axioms pio_certificate_backed
#print axioms hold_floor_cert_reversible
#print axioms hold_floor_cert_severity
#print axioms hold_floor_certificate_backed
#print axioms hold_cert_grants_no_more_than_pio
#print axioms cert_pio_refines_mech_pio
#print axioms cert_hold_floor_constructible
-- Exposure-indexed certificates and trace safety (W19-W26, adopted v0.12;
-- finding R2-07)
#print axioms step_preserves_inv
#print axioms trace_tier_monotone
#print axioms trace_head_certificate_backed
#print axioms trace_stays_inside
#print axioms trace_stays_inside_prefix
#print axioms pointwise_degenerate
#print axioms budget_binds_traces
#print axioms pointwise_admits_joint_crossing
#print axioms pio_trace_stays_inside

-- Module 2: Crisis Frequency Cap & Structural Review (§12.3); Axiom II (§4.2)
#print axioms window_head_bound
#print axioms rolling_window_bound
#print axioms no_permanent_emergency
#print axioms no_emergency_in_review
#print axioms review_absorbing
#print axioms review_gate
#print axioms axiomII_dichotomy
-- Composed cap x review semantics (G1-G7, adopted v0.2; finding AHC-P1-001)
#print axioms dayStep_valid
#print axioms dayRun_valid
#print axioms review_day_never_emergency
#print axioms review_exit_iff_output
#print axioms trip_forced
#print axioms review_run
#print axioms review_gate_composed
#print axioms emergency_day_provenance
#print axioms composed_cap_safety
#print axioms composed_no_permanent_emergency

-- Module 3: Byzantine Measurement Consensus (§8.3); Axiom I (§4.1, §1.1)
#print axioms honest_strict_majority
#print axioms exists_honest_le
#print axioms exists_honest_ge
#print axioms median_bracketed
#print axioms no_corrupt_certificate
#print axioms axiomI_null_kernel
#print axioms axiomI_no_compensation
#print axioms null_kernel_product
#print axioms globalSignal_pos_iff
#print axioms sum_admits_masking

-- Module 4: PLOL Register Invariance (§10.4; Companion A §5, §19.4, App. B)
#print axioms AHC.PLOL.hash_bridge_origin
#print axioms AHC.PLOL.bridge_proves_origin_not_consistency
#print axioms AHC.PLOL.compliant_registers_agree
#print axioms AHC.PLOL.divergence_convicts
#print axioms AHC.PLOL.residual_divergence_noncritical
#print axioms AHC.PLOL.tripartite_single_origin
#print axioms AHC.PLOL.no_hostage
#print axioms AHC.PLOL.contestability_at_breach
#print axioms AHC.PLOL.scr_no_fabrication
-- D-R4 disclosures (P7-P9, adopted v0.5; ruling D-R4)
#print axioms AHC.PLOL.pio_disclosure_at_breach
#print axioms AHC.PLOL.pio_disclosure_divergence_convicts
#print axioms AHC.PLOL.attested_budget_accurate
#print axioms AHC.PLOL.attested_budget_bounded
-- Later-register compliance (P10-P13, adopted v0.7)
#print axioms AHC.PLOL.tripartite_critical_consensus
#print axioms AHC.PLOL.later_registers_no_hostage
#print axioms AHC.PLOL.shipped_pio_disclosure_all_registers
#print axioms AHC.PLOL.later_residual_divergence_noncritical
-- Typed D-R4 claim language (P14-P17, adopted v0.8; findings R2-02, R2-04)
#print axioms AHC.PLOL.pio_roles_distinct
#print axioms AHC.PLOL.pio_register_budget_accurate
#print axioms AHC.PLOL.pio_budget_no_drift
#print axioms AHC.PLOL.pio_disclosed_budget_bounded
-- Exceedance derivation: Module 1 x Module 3 (X1-X4, adopted v0.6)
#print axioms AHC.derived_exceedance_honest_witnessed
#print axioms AHC.derived_exceedance_not_forgeable
#print axioms AHC.hold_sustained_only_by_witnessed_danger
#print axioms AHC.manufactured_danger_cannot_sustain_hold

-- Module 5: Seam Ledger — Contested Attestation Ledger (imported Veriticide
-- machinery; adopted v0.13). Tier A state-machine invariants (L1-L5) +
-- Tier B opaque-predicate relations (L6-L9).
#print axioms AHC.SeamLedger.no_naked_authority_bit
#print axioms AHC.SeamLedger.naked_issue_no_pending
#print axioms AHC.SeamLedger.counterrecord_persists
#print axioms AHC.SeamLedger.counterrecord_persists_run
#print axioms AHC.SeamLedger.counterrecord_digest_stable
#print axioms AHC.SeamLedger.step_one_never_implies_step_two
#print axioms AHC.SeamLedger.remedy_label_not_remedy
#print axioms AHC.SeamLedger.remedy_stages_distinct
#print axioms AHC.SeamLedger.contested_cannot_unlock_irreversible
#print axioms AHC.SeamLedger.contested_blocks_trace
#print axioms AHC.SeamLedger.seam_trace_stays_inside
#print axioms AHC.SeamLedger.issuer_not_sole_validator
#print axioms AHC.SeamLedger.interested_actor_cannot_self_close
#print axioms AHC.SeamLedger.challenge_requires_merits_response
#print axioms AHC.SeamLedger.criticality_cannot_suppress_typed_conflict
-- v0.14: gating the naked issuing interface (L10-L11)
#print axioms AHC.SeamLedger.seam_no_naked_initiation
#print axioms AHC.SeamLedger.seam_initiation_requires_accompaniment
