# AHC Verified Constitutional Kernel

**Version 0.12** — closes finding R2-07, the last open formal item of
the Reviewer #2 report, with exposure-indexed certificates: a
state-transition `TEnvelope` whose certification judges each action at
the deployment's accumulated exposure, an invariant-preservation
obligation carried as structure fields, and trace-safety theorems
W19–W26 — sub-causal traces provably stay inside the certified region
(W21), the pointwise regime is the conserved degenerate case (W23), and
the reviewer's liquidity example is formalized both as the bound (W24)
and as the contrast witness (W25). v0.11 was the claim-surface alignment
pass (findings R2-05, R2-08, R2-09): `residual_divergence_harmless` and its
later-register form are renamed `_noncritical` to state exactly what
they prove, with the completeness of the critical classification now an
explicit seam obligation; the exceedance bridge's glosses are narrowed
to one-honest-witness non-fabrication with the free threshold θ named a
deployment obligation; and Axiom II's dichotomy is reglossed as a
well-formedness lemma with its operational content a named candidate.
No proof changed. v0.10 closed findings R2-03 and R2-06: Layer 0
review outputs are typed dispositions (a denial or close can never reach
the restart-permitting state; only an explicit new-episode authorization
can), and the continuity-hold carries a mandatory-review clock — an
unreviewed hold under continuing risk lands in the flagged `overdue`
state within 72 hours (E12–E15; E1/E2 strengthened). v0.9 closed R2-01,
the report's most severe: PIO and continuity-hold authorization are
lifted onto the certificate-bearing action layer (`pioAuthorizesC`,
`CHoldPolicy`; W10–W18), so the emergency path can no longer authorize
routing outside an envelope certificate, and the legacy
mechanism-granularity table is quarantined to a proved outer bound
(W17). v0.8 closed R2-02/R2-04: a
typed D-R4 claim language ties the disclosed episode budget to the
attestation that proves it — disclosed, attested, and machine-computed
are one term — and makes the four disclosure roles distinct by
construction (P14–P17). Earlier: v0.6/v0.7 closed the two F-4 formalization candidates from the
v0.5 circulation brief (exceedance derived from the Byzantine measurement
layer, X1–X4; register invariance extended to the later civic and
technical records, P10–P13); v0.4 implemented the four ratified
dispositions (episode machine E1–E11; reversibility envelopes W1–W9);
v0.5 formalized the D-R4 disclosures (P7–P9). Change record in
`ERRATA_AND_AMENDMENTS.md`; source digest and audit footprint in the
version manifest — `docs/MANIFEST_v0.12.txt` in the source repository,
shipped as `MANIFEST.txt` alongside this project directory in the
circulation packet.

Machine-checked formalization (Lean 4) of the order-theoretic core of
**Axiomatic Humanist Cybernetics v3.1** — the Tiered Evidence-Action
Protocol with temporal hysteresis, the Crisis Frequency Cap and Structural
Review gate (including their composition), Byzantine measurement
consensus, Axioms I and II, and the Plain Language Output Layer's
register-invariance guarantees.

**Toolchain:** Lean 4.15.0, core only — **no Mathlib dependency**. Every
proof is self-contained. **Zero `sorry`s.** No theorem depends on
`Classical.choice`; the complete axiom footprint is `propext` and
`Quot.sound` (standard Lean kernel axioms), and forty-nine of the
one hundred sixteen audited theorems depend on no axioms at all — including the
PLOL module's register-invariance and disclosure theorems (P1–P8,
P10–P16; the two cross-module budget bounds P9 and P17 route through
Module 1 and so carry `[propext, Quot.sound]`).

## What is and is not verified

These proofs verify the **specification, not the world**. They establish
that the protocol *as written* cannot authorize irreversible force on
sub-causal evidence, cannot hold an emergency open indefinitely, cannot
have its thresholds dragged outside the envelope of honest measurement by
a captured sensor minority, and cannot report global viability over a
collapsed subgraph. Whether measured signals track real harm, whether
sensors are in fact independent, and whether the Layer 0 institutions
function are empirical and institutional questions outside the kernel
(AHC §2.2–2.3, OP.1). Verification-from-above is one half of the
architecture; legibility-from-below (PLOL, Layer 0) is the other, and
nothing here substitutes for it.

## Theorem ↔ specification map

### Module 1 — `AHCKernel/TieredProtocol.lean`

| Theorem | Spec | Statement |
|---|---|---|
| `tier_monotone` (T1) | §5.4 | Authorization is upward-closed in evidence strength |
| `severity_le_evidence` (T2) | §5.4 | Response severity never exceeds evidence tier: force cannot outrun proof |
| `sub_causal_reversible` (T3) | §5.4 | Everything authorized below Tier 3 is reversible |
| `irreversible_iff_causal` (T4) | §5.4, §5.5 | Irreversible mechanisms are authorized *iff* full causal identification holds |
| `broadcast_universal` (T5) | §9.3 (M4) | The transparency broadcast is authorized at every tier |
| `pio_ceiling` (T6) | §5.4 (Tier 0-PIO) | No PIO state authorizes above Tier-1 severity |
| `pio_reversible` (T7) | §5.4 | Everything a PIO authorizes is reversible |
| `pio_resolves` (T8) | §5.4 | A PIO cannot remain pending past the 72h deadline: confirmed or auto-reversed |
| `no_chatter` (T9) | §9.2 | The hysteresis gap makes simultaneous escalate/de-escalate unsatisfiable (instantaneous; see S3 for the temporal claim) |
| `oscillation_travel` (S1) | §9.2 | Escalating and de-escalating values are separated by more than the gap width |
| `flips_travel_anchored` (S2) | §9.2 | Anchored bound: every posture flip costs the signal more than the gap width of travel |
| `chatter_requires_travel` (S3) | §9.2 | (flips − 1)·(gapWidth+1) ≤ total variation: cycling requires repeated genuine full-band swings; sub-band noise flips the posture at most once |
| `episode_no_relitigation` (E1) | §5.4 | Two clocks: without novel evidence or a new-episode disposition — close/continue dispositions may flow freely — whatever the exceedance pattern, unconfirmed full protection ≤ 72h |
| `episode_single_issuance` (E2) | §5.4 | One full-PIO issuance per such span |
| `expiry_routes_by_risk` (E3) | §5.4 | At the deadline: continuing risk → continuity-hold; subsided risk → spent |
| `reonset_refloors` / `floor_persists` (E4–E5) | §5.4 | The floor follows the risk and is never withdrawn while it persists unreviewed — `overdue` keeps the floor |
| `hold_resolution_iff` (E6) | §5.4 | Only an explicit new-episode disposition returns the hold to the restart-permitting posture — a denial or close cannot (R2-03) |
| `novel_restart_from_spent` / `_from_hold` (E7) | §5.4 | An attested materially new claim restarts the full clock |
| `exceedance_cannot_restart` (E8) | §5.4 | Continuity of a signal is never continuity of the full authority — from `hold`, `spent`, or `overdue` |
| `hold_floor_reversible` / `_severity` / `hold_grants_no_more_than_pio` (E9–E11) | §5.4 | The hold floor is reversible, Tier-1-capped, and a remnant of PIO authority — never an extension |
| `close_cannot_launder` (E12) | §5.4 | A close disposition followed by a stale filing cannot reach the full clock: the R2-03 witness, negated |
| `hold_clock_bounded` (E13) | §5.4 | No reachable hold state carries a clock at or past the mandatory-review deadline |
| `unreviewed_hold_expires` (E14) | §5.4 | Under continuing exceedance with no disposition, the hold reaches flagged `overdue` within its deadline and stays there (R2-06) |
| `overdue_absorbing` / `overdue_resolution_iff` (E15) | §5.4 | While risk persists only a disposition exits `overdue`, and only new-episode reaches ordinary posture |
| `cert_tier_monotone` / `cert_severity_le_evidence` (W1–W2) | §5.4 | T1/T2 lifted to certificate-bearing actions |
| `cert_sub_causal_reversible` (W3) | §5.4 | Everything authorized below Tier 3 is reversible — routing AND severance — as a consequence of gating |
| `cert_irreversible_iff_causal` (W4) | §5.4, §5.5 | T4 lifted to certificate-bearing actions |
| `uncertified_routing_needs_causal` / `uncertified_severance_needs_causal` (W5) | §5.4 | No certificate ⇒ Tier 3; Q2 answered: uncertified severance is treated exactly as irreversible |
| `certified_route_at_t1` / `certified_severance_at_t2` (W6) | §5.4 | The graduated ladder is preserved where reversibility is demonstrated |
| `cert_refinement_conservative` (W7) | §5.4 | The §9.3 table is a floor envelopes raise but never lower |
| `no_certificate_no_presumption` (W8) | §5.4 | Reversibility of routing/severance is exactly its certificate |
| `zero_envelope_constructible` (W9) | §5.4 | A deployment with no presumptively reversible routing or severance is a legal parameterization |
| `pio_cert_ceiling` / `pio_cert_reversible` (W10–W11) | §5.4 | T6/T7 lifted to certified actions: the emergency channel is severity-capped and reversible in the envelope sense, not by the Phase 1 table's fiat |
| `pio_certificate_backed` (W12) | §5.4 | A PIO authorizes routing only inside its envelope certificate, and no severance or sanction in any state (finding R2-01 closed) |
| `hold_floor_cert_reversible` / `_severity` (W13–W14) | §5.4 | E9/E10 lifted: the certified hold floor's reversibility is a theorem of the gating, not a field |
| `hold_floor_certificate_backed` (W15) | §5.4 | The floor's routing carries its certificate; severance and sanctions are unconstructible in it |
| `hold_cert_grants_no_more_than_pio` (W16) | §5.4 | E11 lifted: the certified floor is a remnant of PIO authority under the same envelope |
| `cert_pio_refines_mech_pio` (W17) | §5.4 | Quarantine: the certified layer never grants an action whose mechanism the Phase 1 table would refuse |
| `cert_hold_floor_constructible` (W18) | §5.4 | Non-vacuity: a broadcast-only certified floor exists for every envelope, including the zero envelope |
| `trace_tier_monotone` (W19) | §5.4 | T1/W1 at trace altitude: stronger evidence never de-authorizes a trace |
| `trace_head_certificate_backed` (W20) | §5.4 | Every action of a sub-causal trace is certificate-backed at its own exposure point |
| `trace_stays_inside` / `_prefix` (W21–W22) | §5.4 | A finite trace authorized below Tier 3 from inside the certified region stays inside it, at every intermediate point: joint threshold-crossing by individually certified actions is unconstructible (R2-07) |
| `pointwise_degenerate` (W23) | §5.4 | Every pointwise envelope is the trivial-exposure special case, authorizing exactly what it did: existing deployments are conserved |
| `budget_binds_traces` (W24) | §5.4 | Under the cumulative-budget certificate, total routed volume over any authorized trace is within budget |
| `pointwise_admits_joint_crossing` (W25) | §5.4 | Contrast witness: two actions each certified at frozen zero exposure whose two-action trace is refused |
| `pio_trace_stays_inside` (W26) | §5.4 | Tier-1 (PIO-grade) authorized sequences keep the exposure invariant: the R2-01 and R2-07 closures compose |

### Module 2 — `AHCKernel/CrisisCap.lean`

| Theorem | Spec | Statement |
|---|---|---|
| `window_head_bound` (C1) | Companion A §12.3 | The current rolling window carries at most T_cap emergency days |
| `rolling_window_bound` (C2) | §12.3 | The bound holds for every historical window at every offset |
| `no_permanent_emergency` (C3) | §12.3 | No protocol-valid history contains more than T_cap consecutive emergency days |
| `no_emergency_in_review` (C4) | §12.3 | No event grants emergency authority during Structural Review |
| `review_absorbing` (C5) | §12.3 | Review survives any event sequence lacking a Layer 0 output |
| `review_gate` (C6) | §12.3 | Across any output-free span, emergency authority is never granted |
| `axiomII_dichotomy` (A2a) | §4.2 | Well-formedness of the §4.2 classification: every episode is exactly one of reversibility-claim-valid or locally terminal; the operational content of Axiom II (terminality forcing a change of procedure) is a named formalization candidate |
| `dayStep_valid` / `dayRun_valid` (G1) | §12.3 | Every reachable trace of the composed cap × review machine is protocol-valid: C1–C3 apply verbatim |
| `review_day_never_emergency` (G2) | §12.3 | In review, the appended day is `false` for every input: an emergency day during review is unconstructible |
| `review_exit_iff_output` (G3) | §12.3 | Review closes exactly on a Layer 0 output |
| `trip_forced` (G4) | §12.3 | Continued exceedance over a saturated window must trip into review: the trip is derived from the window arithmetic, not discretionary |
| `review_run` / `review_gate_composed` (G5) | §12.3 | Across any output-free span, review persists and the trace extension is all-`false` |
| `emergency_day_provenance` (G6) | §12.3 | Inversion: every emergency day was individually authorized — operational mode, actual request, window strictly below cap |
| `composed_cap_safety` / `composed_no_permanent_emergency` (G7) | §12.3 | C1/C2/C3 restated of the composed machine from its initial state |

### Module 3 — `AHCKernel/SensorsAndKernel.lean`

| Theorem | Spec | Statement |
|---|---|---|
| `honest_strict_majority` (B1) | §8.3 | Under m > 2f+1, honest sensors outnumber corrupted by ≥ 2 |
| `exists_honest_le` / `exists_honest_ge` (B2) | §8.3 | Any f+1 readings at/below (at/above) a value include an honest one |
| `median_bracketed` (B3) | §8.3 | Any median-type statistic is bracketed by honest readings on both sides |
| `no_corrupt_certificate` (B4) | §8.3 | No coalition of ≤ f sensors can certify a reading no honest sensor made |
| `axiomI_null_kernel` (A1a) | §4.1 | One non-viable subgraph nullifies global viability, regardless of all others |
| `axiomI_no_compensation` (A1b) | §4.1 | Global viability certifies every subgraph individually |
| `null_kernel_product` (A1c) | §4.1 | Product form: a zero anywhere forces the global signal to zero, for every prefix and suffix |
| `globalSignal_pos_iff` (A1d) | §4.1 | The global signal is nonzero iff every subgraph signal is |
| `sum_admits_masking` (A1e) | §1.1 | Aggregation by sum provably admits the Korematsu Illusion (witness exhibited); by A1c, the product does not |

### Module 4 — `AHCKernel/PLOL.lean`

| Theorem | Spec | Statement |
|---|---|---|
| `hash_bridge_origin` (P1) | Comp. A §5.1 (Def 5.3) | Equal digests identify a single classification event (under stated collision-freeness) |
| `tripartite_single_origin` (P1') | §19.4 | The three registers of a valid release carry one digest: one event, three voices |
| `bridge_proves_origin_not_consistency` (P2) | §19.4.1 | The spec's own limitation as a theorem-with-witness: equal digests with divergent content exist; the bridge cannot carry consistency |
| `compliant_registers_agree` (P3) | App. B.4 | Two compliant registers agree exactly on the contestation-critical fragment |
| `divergence_convicts` (P3') | App. B.4 | A critical claim absent from a register proves that register non-compliant — divergence is a conviction, not a judgment call |
| `residual_divergence_noncritical` (P4) | §19.4.1 | Under compliance, register differences are confined to genuine claims not marked critical; "framing, never findings" additionally requires completeness of the critical classification (a seam obligation) |
| `no_hostage` (P5) | §19.4 | Every critical claim is public at hour zero; contestation never waits on the litigation track |
| `contestability_at_breach` (P5') | App. B.2 | The falsification condition ships in the T+0 record: the key ships with the lock |
| `decCompliant` (P6) | App. B.4 | Compliance is decidable: given extracted claim sets, the divergence audit is mechanical |
| `pio_disclosure_at_breach` (P7) | D-R4 | A valid PIO release ships authorization basis, novelty basis, episode budget, and falsification condition in the T+0 record at hour zero |
| `pio_disclosure_divergence_convicts` (P7') | D-R4 | Omission of any D-R4 field from any register convicts that register |
| `attested_budget_accurate` (P8) | D-R4 | The budget figure carries a proof it equals the episode machine's accounting |
| `attested_budget_bounded` (P9) | D-R4 | Cross-module: an attested budget over a novelty-free, review-free span is ≤ 72h, by E1 |
| `tripartite_critical_consensus` (P10) | §19.4 | The three registers of a shipped compliant release agree on the entire contestation-critical fragment |
| `later_registers_no_hostage` (P11) | §19.4 | Every critical claim is present in the civic and technical records too |
| `shipped_pio_disclosure_all_registers` (P12) | D-R4 | The four D-R4 fields appear in all three registers of a shipped PIO release |
| `later_residual_divergence_noncritical` (P13) | §19.4.1 | Any claim differing between the later registers is provably a genuine claim not marked critical (see P4's completeness caveat) |
| `pio_roles_distinct` (P14) | D-R4 | The four D-R4 disclosure roles are pairwise distinct claims, by constructor disjointness of the typed claim language |
| `pio_register_budget_accurate` (P15) | D-R4 | Every compliant register contains the budget claim whose figure IS the episode machine's count over the attested history |
| `pio_budget_no_drift` (P16) | D-R4 | Any budget-role claim in the critical set carries the machine's figure: conflicting critical budget disclosures are unconstructible |
| `pio_disclosed_budget_bounded` (P17) | D-R4 | The published figure inherits E1's 72h bound: P9, restated of the disclosed number |

### Bridge — `AHCKernel/ExceedanceBridge.lean` (Module 1 × Module 3)

| Theorem | Spec | Statement |
|---|---|---|
| `derived_exceedance_honest_witnessed` (X1) | §5.4 × §8.3 | A certified exceedance (f+1 sensors ≥ threshold) always has an honest witness, by B2 |
| `derived_exceedance_not_forgeable` (X2) | §5.4 × §8.3 | Honest sensors all below threshold ⇒ exceedance cannot be certified: a captured minority cannot raise the hazard signal alone |
| `hold_sustained_only_by_witnessed_danger` (X3) | §5.4 × §8.3 | Whenever the episode machine keeps a subgraph in a continuity-hold on a derived input, at least one honest sensor witnesses the danger (one-honest-witness non-fabrication, not majority corroboration) |
| `manufactured_danger_cannot_sustain_hold` (X4) | §5.4 × §8.3 | Fabricated alarm drops the subgraph out of the hold to `spent`: the laundering path closed at the measurement layer |

Module 4 also formally locates **the seam**: every theorem operates on
claim sets, and the relation between a natural-language text and the
claim set it expresses is declared unverifiable — that relation is where
Layer 0 community judgment begins. The machine checks everything that
does not require trust, so trust is spent only where it is irreplaceable
(Proposition 5.1 as a division of labor).

## Design idioms worth noting

Constitutive constraints are carried as **structure fields**, not side
conditions: `Hysteresis.gap` (A_reset < A*), `Cap.cap_lt_window`
(T_cap < W), and `Ensemble.quorum` (m > 2f+1) make degenerate
parameterizations *unconstructible* rather than merely invalid. Sensor
honesty is a **ghost variable** — ground truth the running system cannot
observe — which is why the Byzantine theorems quantify over all placements
of at most f corrupted sensors. The Axiom I intersection theorems depend
on **zero axioms**: the formal mirror of the specification's claim that
Axiom I is a constitutional commitment, not a mathematical finding — all
normative weight sits in the choice of aggregation operator, and A1e
exhibits exactly what that choice rules out.

## Building

With [elan](https://github.com/leanprover/elan) installed:

```
lake build
```

The build elaborates all proofs and prints the axiom audit
(`AHCKernel/Audit.lean`) to the log. A `sorry` anywhere would surface as
the `sorryAx` axiom in that output. Expected audit result:

```
116 audited theorems: every one at most [propext, Quot.sound];
never Classical.choice
no axioms at all (49): the T1–T7 gating theorems, the hold-floor and
  certificate-envelope theorems (hold_floor_reversible, hold_floor_severity,
  hold_grants_no_more_than_pio, cert_tier_monotone,
  cert_refinement_conservative, no_certificate_no_presumption,
  zero_envelope_constructible, certified_route_at_t1,
  certified_severance_at_t2), the certified-emergency quarantine and
  constructibility theorems (hold_cert_grants_no_more_than_pio,
  cert_pio_refines_mech_pio, cert_hold_floor_constructible), the
  trace-layer monotonicity, degeneracy, and contrast theorems
  (trace_tier_monotone, pointwise_degenerate,
  pointwise_admits_joint_crossing), the
  composed-machine soundness theorems (dayStep_valid, dayRun_valid),
  the Axiom I intersection theorems, and the PLOL invariance/disclosure
  theorems P1–P8, P10–P16.
  The four exceedance-bridge theorems (X1–X4) and the two cross-module
  budget bounds attested_budget_bounded (P9) and
  pio_disclosed_budget_bounded (P17) route through Module 3 / Module 1
  and carry [propext, Quot.sound].
```

(Counts are audit-log entries — one per `#print axioms` result;
`decCompliant` is a verified `Decidable` instance additional to them.)

## Modeling disclosures

Per the framework's own norm of separating the contestable normative layer
from the formal one, each module header states its modeling choices
explicitly: discretization of time in days/hours; the strict (conservative)
reading of the renewal condition where the spec admits an off-by-one; M3
treated as the irreversibility-bearing mechanism the tier structure gates;
the median characterized by its counting property rather than order
statistics; the enforcement posture as a one-bit Schmitt trigger with
total variation as "travel" (S1–S3); the composed machine's trip condition
as exceedance ∧ failure of the renewal condition, with exceedance a free
input (G1–G7); the two-clock separation with `novel` as a contestable
Layer 0 attestation and the hold floor as a deployment-certified policy
(E1–E11), with Layer 0 outputs as typed dispositions and the hold under
a mandatory-review clock whose constant (72h) is a flagged deployment
choice pending ratification (E12–E15); reversibility envelopes over opaque deployment descriptors,
judged by external certificates the kernel gates on but does not verify
(W1–W9), with the PIO and hold floor authorizing only certified
actions under those envelopes since v0.9 (W10–W18), and certification
exposure-indexed with invariant preservation as the constitutive
obligation since v0.12 — what the exposure state measures is at the
seam (W19–W26); the typed D-R4
claim language, with the budget attestation
carried inside the PIO event and role occupancy formal while claim
content stays at the seam (P14–P17). These choices are the right places
to aim contestation.

## Status and non-goals

This kernel covers the order-theoretic and counting-theoretic core:
enforcement gating, emergency time, measurement, aggregation, and
output-register invariance. It does
not attempt the statistical layer (causal identification, §5.5), viability
kernel dynamics over continuous state spaces, or any claim about
institutional performance. Those are respectively the province of
econometrics, viability theory, and Companion B — and, for the
load-bearing empirical hypotheses, of Layer 0 itself.
